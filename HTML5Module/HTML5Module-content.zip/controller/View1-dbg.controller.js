sap.ui.define([
		"sap/ui/core/mvc/Controller"
	],
	/**
     * 
     */
	function (Controller) {
		"use strict";

		return Controller.extend("ns.HTML5Module.controller.View1", {
			onInit: function () {

            },
            alert:function(){
                alert("kevin")
            }
		});
	});
